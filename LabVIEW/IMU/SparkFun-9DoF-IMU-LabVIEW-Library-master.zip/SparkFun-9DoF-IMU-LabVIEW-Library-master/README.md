# SparkFun-9DoF-IMU-LabVIEW-Library

This is a library/driver written in LabVIEW on the myRIO FPGA to read the LSM9DS1 IMU from sparkfun 

The files contain VIs to 
- Read all the IMU sensors
- Read the Acc, Gyro, or Mag indivisually
